import { GoogleGenAI } from "@google/genai";
import { Match, Team } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const generateMatchCommentary = async (
  match: Match,
  homeTeam: Team,
  awayTeam: Team,
  lastAction: string
): Promise<string> => {
  if (!apiKey) return "AI Commentary Unavailable (Missing API Key)";

  const prompt = `
    You are a professional blind cricket commentator.
    Generate a 2-sentence exciting commentary for the following live match situation in a Blind Cricket match.
    
    Context: Blind cricket uses an audio ball. B1 players are totally blind, B2 partially blind, B3 partially sighted.
    Bowling is underarm.
    
    Match: ${homeTeam.name} vs ${awayTeam.name}
    Venue: ${match.venue}
    Batting Team: ${match.score.currentBattingTeamId === homeTeam.id ? homeTeam.name : awayTeam.name}
    Score: ${match.score.home.runs}/${match.score.home.wickets} (Home) vs ${match.score.away.runs}/${match.score.away.wickets} (Away) if chasing.
    Current Overs: ${match.score.home.overs} (if batting)
    
    The last event was: ${lastAction}
    
    Keep it energetic and mention the unique sounds or specific blind cricket dynamics if relevant.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text || "What a match we are witnessing here!";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "The atmosphere is electric at the stadium!";
  }
};

export const getPlayerAnalysis = async (playerName: string, stats: any): Promise<string> => {
    if (!apiKey) return "AI Analysis Unavailable";
    
    const prompt = `
      Provide a short, punchy 30-word analysis for a blind cricket player named ${playerName}.
      Stats: Matches: ${stats.matches}, Runs: ${stats.runs}, Wickets: ${stats.wickets}, Category: ${stats.category}.
      Highlight their strength.
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        return response.text || "A key player for the team.";
    } catch (error) {
        return "An experienced campaigner.";
    }
}
