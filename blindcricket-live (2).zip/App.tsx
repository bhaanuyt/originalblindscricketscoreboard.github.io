import React, { useState } from 'react';
import { TEAMS, MOCK_MATCHES } from './constants';
import { Match } from './types';
import MatchCard from './components/MatchCard';
import LiveScore from './components/LiveScore';
import PlayerStats from './components/PlayerStats';
import { Trophy, Activity, Users, Menu, Info } from 'lucide-react';

enum View {
  MATCHES = 'MATCHES',
  LIVE_DETAIL = 'LIVE_DETAIL',
  STATS = 'STATS'
}

function App() {
  const [currentView, setCurrentView] = useState<View>(View.MATCHES);
  const [selectedMatchId, setSelectedMatchId] = useState<string | null>(null);

  const handleMatchClick = (id: string) => {
    setSelectedMatchId(id);
    setCurrentView(View.LIVE_DETAIL);
  };

  const activeMatch = selectedMatchId ? MOCK_MATCHES.find(m => m.id === selectedMatchId) : null;
  const teamsArray = Object.values(TEAMS);

  return (
    <div className="min-h-screen bg-gray-50 pb-20 font-sans text-gray-900">
      
      {/* Navbar */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2" onClick={() => setCurrentView(View.MATCHES)} role="button">
            <div className="bg-cricket-green text-white p-2 rounded-lg">
              <Trophy size={20} />
            </div>
            <h1 className="text-xl font-bold text-cricket-green tracking-tight hidden sm:block">BlindCricket<span className="text-gray-800">Live</span></h1>
          </div>
          
          <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-full">
            <button 
              onClick={() => setCurrentView(View.MATCHES)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${currentView === View.MATCHES ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
            >
              Matches
            </button>
            <button 
              onClick={() => setCurrentView(View.STATS)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${currentView === View.STATS ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
            >
              Stats
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto px-4 pt-6">
        
        {currentView === View.MATCHES && (
          <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
            <section>
              <h2 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                <Activity className="text-red-500" size={18} />
                Live Matches
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 {MOCK_MATCHES.filter(m => m.status === 'LIVE').map(match => (
                   <MatchCard 
                     key={match.id}
                     match={match}
                     homeTeam={TEAMS[match.homeTeamId]}
                     awayTeam={TEAMS[match.awayTeamId]}
                     onClick={() => handleMatchClick(match.id)}
                   />
                 ))}
                 {MOCK_MATCHES.filter(m => m.status === 'LIVE').length === 0 && (
                   <div className="col-span-2 text-center py-10 bg-white rounded-xl border border-dashed border-gray-300 text-gray-500">
                     No live matches at the moment.
                   </div>
                 )}
              </div>
            </section>

            <section>
              <h2 className="text-lg font-bold text-gray-800 mb-4">Upcoming Fixtures</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 {MOCK_MATCHES.filter(m => m.status === 'UPCOMING').map(match => (
                   <MatchCard 
                     key={match.id}
                     match={match}
                     homeTeam={TEAMS[match.homeTeamId]}
                     awayTeam={TEAMS[match.awayTeamId]}
                     onClick={() => handleMatchClick(match.id)}
                   />
                 ))}
              </div>
            </section>
            
            <section className="bg-blue-50 rounded-xl p-6 border border-blue-100 mt-8">
              <div className="flex items-start gap-3">
                 <Info className="text-blue-600 mt-1" />
                 <div>
                   <h3 className="font-bold text-blue-800">About Blind Cricket</h3>
                   <p className="text-sm text-blue-700 mt-1 leading-relaxed">
                     Blind cricket is played with a sweeping audio ball containing ball bearings. 
                     Teams consist of 11 players categorised into:
                   </p>
                   <ul className="text-sm text-blue-700 mt-2 list-disc list-inside space-y-1">
                     <li><span className="font-bold">B1 (4 players):</span> Totally blind. Runs are doubled.</li>
                     <li><span className="font-bold">B2 (3 players):</span> Partially blind.</li>
                     <li><span className="font-bold">B3 (4 players):</span> Partially sighted.</li>
                   </ul>
                 </div>
              </div>
            </section>
          </div>
        )}

        {currentView === View.LIVE_DETAIL && activeMatch && (
          <LiveScore 
            initialMatch={activeMatch}
            homeTeam={TEAMS[activeMatch.homeTeamId]}
            awayTeam={TEAMS[activeMatch.awayTeamId]}
            onBack={() => setCurrentView(View.MATCHES)}
          />
        )}

        {currentView === View.STATS && (
           <div className="animate-in slide-in-from-right-4 duration-500">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Player Statistics</h2>
              <PlayerStats teams={teamsArray} />
           </div>
        )}

      </main>
      
      <footer className="mt-20 border-t border-gray-200 py-8 text-center text-sm text-gray-400">
        <p>© 2024 BlindCricket Live. Designed with accessibility in mind.</p>
      </footer>
    </div>
  );
}

export default App;