export enum BlindCategory {
  B1 = 'B1', // Totally blind
  B2 = 'B2', // Partially blind
  B3 = 'B3'  // Partially sighted
}

export enum MatchStatus {
  LIVE = 'LIVE',
  UPCOMING = 'UPCOMING',
  FINISHED = 'FINISHED'
}

export interface Player {
  id: string;
  name: string;
  teamId: string;
  category: BlindCategory;
  role: 'Batsman' | 'Bowler' | 'All-Rounder' | 'Wicketkeeper';
  stats: {
    matches: number;
    runs: number;
    wickets: number;
    average: number;
    strikeRate: number;
  };
  isCaptain?: boolean;
}

export interface Team {
  id: string;
  name: string;
  shortName: string;
  flag: string; // Emoji or URL
  color: string;
  players: Player[];
}

export interface BallEvent {
  over: number;
  ball: number;
  run: number;
  isWicket: boolean;
  bowler: string;
  batsman: string;
  commentary?: string;
}

export interface Match {
  id: string;
  homeTeamId: string;
  awayTeamId: string;
  status: MatchStatus;
  date: string;
  venue: string;
  score: {
    home: { runs: number; wickets: number; overs: number };
    away: { runs: number; wickets: number; overs: number };
    currentBattingTeamId: string;
  };
  currentOver: BallEvent[];
}
