import React, { useState } from 'react';
import { Player, BlindCategory, Team } from '../types';
import { Eye, EyeOff, Shield, Award } from 'lucide-react';
import { getPlayerAnalysis } from '../services/geminiService';

interface PlayerStatsProps {
  teams: Team[];
}

const CategoryBadge = ({ category }: { category: BlindCategory }) => {
  let color = '';
  let Icon = Eye;
  
  switch (category) {
    case BlindCategory.B1:
      color = 'bg-red-100 text-red-800 border-red-200';
      Icon = EyeOff;
      break;
    case BlindCategory.B2:
      color = 'bg-yellow-100 text-yellow-800 border-yellow-200';
      Icon = Shield; // Metaphor for partial
      break;
    case BlindCategory.B3:
      color = 'bg-green-100 text-green-800 border-green-200';
      Icon = Eye;
      break;
  }

  return (
    <span className={`flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold border ${color}`}>
      <Icon size={12} />
      {category}
    </span>
  );
};

const PlayerStats: React.FC<PlayerStatsProps> = ({ teams }) => {
  const [selectedTeamId, setSelectedTeamId] = useState<string>(teams[0].id);
  const [aiAnalysis, setAiAnalysis] = useState<Record<string, string>>({});
  const [loadingAnalysis, setLoadingAnalysis] = useState<string | null>(null);

  const selectedTeam = teams.find(t => t.id === selectedTeamId) || teams[0];

  const handleAnalyze = async (player: Player) => {
    if (aiAnalysis[player.id]) return;
    setLoadingAnalysis(player.id);
    const analysis = await getPlayerAnalysis(player.name, { ...player.stats, category: player.category });
    setAiAnalysis(prev => ({ ...prev, [player.id]: analysis }));
    setLoadingAnalysis(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 overflow-x-auto pb-2 no-scrollbar">
        {teams.map(team => (
          <button
            key={team.id}
            onClick={() => setSelectedTeamId(team.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-full font-medium transition-colors whitespace-nowrap
              ${selectedTeamId === team.id 
                ? 'bg-cricket-green text-white shadow-md' 
                : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-200'}`}
          >
            <span className="text-xl">{team.flag}</span>
            {team.name}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {selectedTeam.players.map(player => (
          <div key={player.id} className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 hover:border-cricket-grass transition-all">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h3 className="font-bold text-gray-900 text-lg">{player.name}</h3>
                <p className="text-sm text-gray-500">{player.role}</p>
              </div>
              <CategoryBadge category={player.category} />
            </div>

            <div className="grid grid-cols-3 gap-2 mb-4">
              <div className="bg-gray-50 p-2 rounded-lg text-center">
                <span className="block text-xs text-gray-400 uppercase">Runs</span>
                <span className="block font-bold text-gray-800">{player.stats.runs}</span>
              </div>
              <div className="bg-gray-50 p-2 rounded-lg text-center">
                <span className="block text-xs text-gray-400 uppercase">Wkts</span>
                <span className="block font-bold text-gray-800">{player.stats.wickets}</span>
              </div>
              <div className="bg-gray-50 p-2 rounded-lg text-center">
                <span className="block text-xs text-gray-400 uppercase">Mat</span>
                <span className="block font-bold text-gray-800">{player.stats.matches}</span>
              </div>
            </div>

            <div className="border-t border-gray-100 pt-3">
              {aiAnalysis[player.id] ? (
                <p className="text-xs text-gray-600 italic bg-blue-50 p-2 rounded border border-blue-100">
                  <span className="font-bold text-blue-600 not-italic mr-1">AI Scout:</span>
                  "{aiAnalysis[player.id]}"
                </p>
              ) : (
                <button 
                  onClick={() => handleAnalyze(player)}
                  disabled={loadingAnalysis === player.id}
                  className="w-full flex items-center justify-center gap-2 text-xs font-medium text-blue-600 hover:text-blue-700 py-1"
                >
                  <Award size={14} />
                  {loadingAnalysis === player.id ? 'Scouting...' : 'Get AI Analysis'}
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PlayerStats;