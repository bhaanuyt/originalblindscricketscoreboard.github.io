import React, { useState, useEffect, useCallback } from 'react';
import { Match, Team, BallEvent, Player, BlindCategory } from '../types';
import { generateMatchCommentary } from '../services/geminiService';
import { PlayCircle, Mic, Users, Trophy, Volume2 } from 'lucide-react';

interface LiveScoreProps {
  initialMatch: Match;
  homeTeam: Team;
  awayTeam: Team;
  onBack: () => void;
}

const LiveScore: React.FC<LiveScoreProps> = ({ initialMatch, homeTeam, awayTeam, onBack }) => {
  const [match, setMatch] = useState<Match>(initialMatch);
  const [commentary, setCommentary] = useState<string>("Match started. India elected to bat first.");
  const [isSimulating, setIsSimulating] = useState(false);
  
  // Dummy state to track "on strike" batter index for demo
  const [strikerIndex, setStrikerIndex] = useState(0);
  const [nonStrikerIndex, setNonStrikerIndex] = useState(1);
  const [bowlerIndex, setBowlerIndex] = useState(10); // Start with last player as bowler for opponent

  const handleSimulateBall = useCallback(async () => {
    setIsSimulating(true);
    
    // Random event logic
    const outcomes = [0, 1, 1, 2, 4, 6, 0, 'W', 1, 0, 2];
    const outcome = outcomes[Math.floor(Math.random() * outcomes.length)];
    
    setMatch(prev => {
      const newMatch = { ...prev };
      const runs = typeof outcome === 'number' ? outcome : 0;
      const isWicket = outcome === 'W';
      
      // Update scores (Assuming Home team batting for simplicity of demo)
      newMatch.score.home.runs += runs;
      if (isWicket) newMatch.score.home.wickets += 1;
      
      // Update overs
      const currentBalls = Math.round((newMatch.score.home.overs % 1) * 10);
      let newBalls = currentBalls + 1;
      let newOvers = Math.floor(newMatch.score.home.overs);
      
      if (newBalls === 6) {
        newOvers += 1;
        newBalls = 0;
      }
      
      newMatch.score.home.overs = newOvers + (newBalls / 10);

      return newMatch;
    });

    const actionDescription = typeof outcome === 'number' 
      ? `${outcome} runs scored.` 
      : `WICKET! A huge moment in the match.`;

    const aiComm = await generateMatchCommentary(match, homeTeam, awayTeam, actionDescription);
    setCommentary(aiComm);
    setIsSimulating(false);
  }, [match, homeTeam, awayTeam]);

  // Playing XI Component Helper
  const PlayingXI = ({ team }: { team: Team }) => (
    <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
      <div className="flex items-center gap-2 mb-3 pb-2 border-b border-gray-100">
        <span className="text-xl">{team.flag}</span>
        <h3 className="font-bold text-gray-800">{team.name} XI</h3>
      </div>
      <ul className="space-y-2">
        {team.players.map((p, i) => (
          <li key={p.id} className="flex justify-between items-center text-sm">
            <div className="flex items-center gap-2">
              <span className="text-gray-400 font-mono w-4">{i + 1}</span>
              <span className="text-gray-700 font-medium">{p.name}</span>
            </div>
            <span className={`text-[10px] px-1.5 rounded ${
              p.category === BlindCategory.B1 ? 'bg-red-100 text-red-700' :
              p.category === BlindCategory.B2 ? 'bg-yellow-100 text-yellow-700' :
              'bg-green-100 text-green-700'
            }`}>
              {p.category}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {/* Header / Scoreboard */}
      <div className="bg-gradient-to-br from-cricket-green to-emerald-900 rounded-2xl p-6 text-white shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-10">
          <Trophy size={120} />
        </div>
        
        <button onClick={onBack} className="text-emerald-200 hover:text-white text-sm font-medium mb-4 flex items-center gap-1">
           &larr; Back to Matches
        </button>

        <div className="flex flex-col md:flex-row justify-between items-center gap-6 relative z-10">
          {/* Home Team Score */}
          <div className="text-center md:text-left">
            <div className="flex items-center gap-3 mb-1">
              <span className="text-3xl">{homeTeam.flag}</span>
              <h2 className="text-2xl font-bold">{homeTeam.name}</h2>
            </div>
            <div className="text-5xl font-mono font-bold tracking-tight">
              {match.score.home.runs}/{match.score.home.wickets}
            </div>
            <div className="text-emerald-300 font-medium mt-1 text-lg">
              {match.score.home.overs.toFixed(1)} Overs
            </div>
          </div>

          <div className="text-center">
             <div className="bg-black/20 backdrop-blur-sm px-4 py-2 rounded-lg border border-white/10">
               <p className="text-xs text-emerald-200 uppercase tracking-wider mb-1">Current Run Rate</p>
               <p className="text-xl font-bold">
                 {(match.score.home.runs / (Math.max(1, match.score.home.overs))).toFixed(2)}
               </p>
             </div>
          </div>

          {/* Away Team (Yet to bat or chasing) */}
          <div className="text-center md:text-right opacity-80">
            <div className="flex items-center justify-center md:justify-end gap-3 mb-1">
              <h2 className="text-xl font-bold">{awayTeam.name}</h2>
              <span className="text-2xl">{awayTeam.flag}</span>
            </div>
            <div className="text-2xl font-mono font-bold">
              {match.score.away.runs}/{match.score.away.wickets}
            </div>
            <div className="text-emerald-300 text-sm mt-1">
              Yet to bat
            </div>
          </div>
        </div>

        {/* Action Bar */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-white/10 pt-4">
          <div className="flex items-center gap-2 text-sm text-emerald-100">
            <span className="inline-block w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
            LIVE from {match.venue.split(',')[0]}
          </div>
          
          <button 
            onClick={handleSimulateBall}
            disabled={isSimulating}
            className="flex items-center gap-2 bg-white text-cricket-green px-6 py-2 rounded-full font-bold shadow-lg hover:bg-emerald-50 hover:scale-105 transition-all disabled:opacity-50 disabled:scale-100"
          >
            {isSimulating ? (
              <>Simulating...</>
            ) : (
              <>
                <PlayCircle size={18} />
                Simulate Next Ball
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Col: Commentary & Current Status */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* AI Commentary Box */}
          <div className="bg-white rounded-xl shadow-sm border border-purple-100 overflow-hidden">
            <div className="bg-gradient-to-r from-purple-50 to-white px-4 py-3 border-b border-purple-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="bg-purple-100 p-1.5 rounded-md text-purple-600">
                  <Mic size={16} />
                </div>
                <h3 className="font-bold text-gray-800">Live Commentary</h3>
              </div>
              <span className="text-[10px] font-medium bg-purple-100 text-purple-700 px-2 py-1 rounded-full flex items-center gap-1">
                <Volume2 size={10} />
                AI Powered
              </span>
            </div>
            <div className="p-5">
              <p className="text-gray-700 text-lg leading-relaxed font-medium">
                "{commentary}"
              </p>
            </div>
          </div>

          {/* Batting Card */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="bg-gray-50 px-4 py-3 border-b border-gray-100 font-bold text-gray-700">
              Batting
            </div>
            <div className="divide-y divide-gray-50">
              {/* Batter 1 */}
              <div className="p-4 flex justify-between items-center bg-emerald-50/30">
                <div className="flex items-center gap-3">
                   <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center font-bold text-gray-500 text-xs">B2</div>
                   <div>
                     <p className="font-bold text-gray-900 flex items-center gap-2">
                       {homeTeam.players[strikerIndex].name} <span className="text-emerald-600">*</span>
                     </p>
                     <p className="text-xs text-gray-500">45 (32) • SR 140.6</p>
                   </div>
                </div>
                <div className="font-mono font-bold text-xl text-gray-800">45</div>
              </div>
              {/* Batter 2 */}
              <div className="p-4 flex justify-between items-center">
                <div className="flex items-center gap-3">
                   <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center font-bold text-gray-500 text-xs">B3</div>
                   <div>
                     <p className="font-bold text-gray-900">
                       {homeTeam.players[nonStrikerIndex].name}
                     </p>
                     <p className="text-xs text-gray-500">12 (15) • SR 80.0</p>
                   </div>
                </div>
                <div className="font-mono font-bold text-xl text-gray-800">12</div>
              </div>
            </div>
          </div>

          {/* Bowling Card */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
             <div className="bg-gray-50 px-4 py-3 border-b border-gray-100 font-bold text-gray-700">
              Bowling
            </div>
             <div className="p-4 flex justify-between items-center">
                <div className="flex items-center gap-3">
                   <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center font-bold text-gray-500 text-xs">B1</div>
                   <div>
                     <p className="font-bold text-gray-900">
                       {awayTeam.players[bowlerIndex].name}
                     </p>
                     <p className="text-xs text-gray-500">Right-arm fast-medium</p>
                   </div>
                </div>
                <div className="text-right">
                   <p className="font-mono font-bold text-gray-800">0/24</p>
                   <p className="text-xs text-gray-500">3.4 overs</p>
                </div>
              </div>
          </div>

        </div>

        {/* Right Col: Squads */}
        <div className="space-y-6">
           <div className="flex items-center gap-2 text-gray-800 font-bold text-lg mb-2">
             <Users size={20} />
             Playing XI
           </div>
           <PlayingXI team={homeTeam} />
           <PlayingXI team={awayTeam} />
        </div>

      </div>
    </div>
  );
};

export default LiveScore;