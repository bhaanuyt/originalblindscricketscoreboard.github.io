import React from 'react';
import { Match, MatchStatus, Team } from '../types';
import { MapPin, Calendar, Activity } from 'lucide-react';

interface MatchCardProps {
  match: Match;
  homeTeam: Team;
  awayTeam: Team;
  onClick: () => void;
}

const MatchCard: React.FC<MatchCardProps> = ({ match, homeTeam, awayTeam, onClick }) => {
  const isLive = match.status === MatchStatus.LIVE;

  return (
    <div 
      onClick={onClick}
      className={`relative overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm transition-all hover:shadow-md cursor-pointer group`}
    >
      {isLive && (
        <div className="absolute top-0 right-0 bg-red-600 text-white text-xs font-bold px-3 py-1 rounded-bl-lg animate-pulse flex items-center gap-1">
          <Activity size={12} /> LIVE
        </div>
      )}
      
      <div className="p-5">
        <div className="flex justify-between items-center mb-4">
          <div className="text-xs text-gray-500 font-medium flex items-center gap-1">
            <Calendar size={12} />
            {new Date(match.date).toLocaleDateString()}
          </div>
          <div className="text-xs text-gray-500 font-medium flex items-center gap-1">
            <MapPin size={12} />
            {match.venue.split(',')[0]}
          </div>
        </div>

        <div className="flex justify-between items-center">
          <div className="flex flex-col items-center w-1/3">
            <div className="text-4xl mb-2">{homeTeam.flag}</div>
            <h3 className="font-bold text-gray-900 text-lg leading-tight text-center">{homeTeam.shortName}</h3>
            {isLive && (
              <p className="font-mono text-xl font-bold text-cricket-green mt-1">
                {match.score.home.runs}/{match.score.home.wickets}
              </p>
            )}
          </div>

          <div className="flex flex-col items-center w-1/3">
            <span className="text-gray-400 font-bold text-sm">VS</span>
            {isLive && <span className="text-xs text-gray-500 mt-1">{match.score.home.overs} ov</span>}
          </div>

          <div className="flex flex-col items-center w-1/3">
            <div className="text-4xl mb-2">{awayTeam.flag}</div>
            <h3 className="font-bold text-gray-900 text-lg leading-tight text-center">{awayTeam.shortName}</h3>
            {isLive && match.score.away.runs > 0 && (
               <p className="font-mono text-xl font-bold text-cricket-green mt-1">
               {match.score.away.runs}/{match.score.away.wickets}
             </p>
            )}
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-gray-100">
           <p className="text-sm text-center text-gray-600">
             {isLive ? 'India chose to bat' : 'Match starts soon'}
           </p>
        </div>
      </div>
    </div>
  );
};

export default MatchCard;