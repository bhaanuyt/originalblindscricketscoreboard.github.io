import { BlindCategory, Match, MatchStatus, Player, Team } from './types';

// Helper to create random players
const createPlayer = (id: string, name: string, teamId: string, category: BlindCategory, role: any, runs: number, wickets: number): Player => ({
  id, name, teamId, category, role,
  stats: { matches: Math.floor(Math.random() * 50) + 10, runs, wickets, average: 35.5, strikeRate: 120.4 }
});

export const TEAM_INDIA: Team = {
  id: 'ind',
  name: 'India',
  shortName: 'IND',
  flag: '🇮🇳',
  color: 'bg-blue-600',
  players: [
    createPlayer('p1', 'Ajay Kumar Reddy', 'ind', BlindCategory.B2, 'All-Rounder', 3200, 45),
    createPlayer('p2', 'Sunil Ramesh', 'ind', BlindCategory.B3, 'Batsman', 4100, 10),
    createPlayer('p3', 'D. Venkateswara Rao', 'ind', BlindCategory.B2, 'All-Rounder', 2100, 30),
    createPlayer('p4', 'Monu Kumar', 'ind', BlindCategory.B1, 'Bowler', 150, 55),
    createPlayer('p5', 'Lalit Meena', 'ind', BlindCategory.B1, 'Batsman', 1800, 5),
    createPlayer('p6', 'Prakash Jayaramaiah', 'ind', BlindCategory.B3, 'Wicketkeeper', 2900, 0),
    createPlayer('p7', 'Deepak Malik', 'ind', BlindCategory.B3, 'All-Rounder', 2500, 25),
    createPlayer('p8', 'Ravi Kumar', 'ind', BlindCategory.B1, 'Bowler', 200, 40),
    createPlayer('p9', 'Sonu Golkar', 'ind', BlindCategory.B2, 'Batsman', 1200, 2),
    createPlayer('p10', 'Mahender Vaishnav', 'ind', BlindCategory.B2, 'Bowler', 300, 60),
    createPlayer('p11', 'Sandeep Singh', 'ind', BlindCategory.B2, 'Batsman', 900, 5),
  ]
};

export const TEAM_PAKISTAN: Team = {
  id: 'pak',
  name: 'Pakistan',
  shortName: 'PAK',
  flag: '🇵🇰',
  color: 'bg-green-600',
  players: [
    createPlayer('pak1', 'Nisar Ali', 'pak', BlindCategory.B2, 'Batsman', 3500, 12),
    createPlayer('pak2', 'Badar Munir', 'pak', BlindCategory.B3, 'All-Rounder', 4000, 50),
    createPlayer('pak3', 'Riasat Khan', 'pak', BlindCategory.B1, 'Bowler', 300, 70),
    createPlayer('pak4', 'Matiullah', 'pak', BlindCategory.B2, 'Batsman', 1500, 5),
    createPlayer('pak5', 'Muhammad Rashid', 'pak', BlindCategory.B3, 'Batsman', 2200, 10),
    createPlayer('pak6', 'Zafar Iqbal', 'pak', BlindCategory.B1, 'All-Rounder', 1100, 35),
    createPlayer('pak7', 'Anees Javed', 'pak', BlindCategory.B2, 'Batsman', 1800, 2),
    createPlayer('pak8', 'Sajid Nawab', 'pak', BlindCategory.B1, 'Bowler', 100, 45),
    createPlayer('pak9', 'Mohsin Khan', 'pak', BlindCategory.B3, 'Wicketkeeper', 2100, 0),
    createPlayer('pak10', 'Israr Hassan', 'pak', BlindCategory.B2, 'Bowler', 400, 55),
    createPlayer('pak11', 'Akmal Hayat', 'pak', BlindCategory.B3, 'Bowler', 250, 48),
  ]
};

export const TEAM_AUSTRALIA: Team = {
  id: 'aus',
  name: 'Australia',
  shortName: 'AUS',
  flag: '🇦🇺',
  color: 'bg-yellow-500',
  players: Array.from({ length: 11 }).map((_, i) => createPlayer(`aus${i}`, `Player AUS ${i+1}`, 'aus', i % 3 === 0 ? BlindCategory.B1 : BlindCategory.B2, 'All-Rounder', 1000, 20))
};

export const TEAMS: Record<string, Team> = {
  ind: TEAM_INDIA,
  pak: TEAM_PAKISTAN,
  aus: TEAM_AUSTRALIA
};

export const MOCK_MATCHES: Match[] = [
  {
    id: 'm1',
    homeTeamId: 'ind',
    awayTeamId: 'pak',
    status: MatchStatus.LIVE,
    date: new Date().toISOString(),
    venue: 'M. Chinnaswamy Stadium, Bengaluru',
    score: {
      home: { runs: 185, wickets: 3, overs: 16.4 },
      away: { runs: 0, wickets: 0, overs: 0 },
      currentBattingTeamId: 'ind'
    },
    currentOver: []
  },
  {
    id: 'm2',
    homeTeamId: 'aus',
    awayTeamId: 'ind',
    status: MatchStatus.UPCOMING,
    date: new Date(Date.now() + 86400000 * 2).toISOString(), // +2 days
    venue: 'Adelaide Oval',
    score: {
      home: { runs: 0, wickets: 0, overs: 0 },
      away: { runs: 0, wickets: 0, overs: 0 },
      currentBattingTeamId: 'aus'
    },
    currentOver: []
  }
];